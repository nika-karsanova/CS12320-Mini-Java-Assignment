import java.util.Objects;


/**
 * Represents all of the Venue objects
 * @author vek1
 * @version 22/03
 */

public class Venue {
    private String name;
    private boolean hasDataProjector;

    public Venue(){}

    public Venue(String name){
        this.name = name;
    }

    /**Returns the name of the venue
     * @return name
     */
    public String getName() {
        return name;
    }

    /** Sets the name for the venue
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**Returns the information about DataProjector need
     * @return hasDataProjector
     */
    public boolean hasDataProjector() {
        return hasDataProjector;
    }

    /** Sets whether or not projector is required
     * @param hasDataProjector
     */
    public void setHasDataProjector(boolean hasDataProjector) {
        this.hasDataProjector = hasDataProjector;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Venue location = (Venue) o;
        return Objects.equals(name, location.name);
    }
    /**
     * Returns information about the Venue
     * @return info for printing
     */
    @Override
    public String toString() {

        StringBuilder results = new StringBuilder(); // CHANGED TO USE STRING BUILDER

        results.append("venue: ");
        results.append(name);
        results.append("which has data Projector ");
        results.append(hasDataProjector);

        return results.toString();

    }
}
