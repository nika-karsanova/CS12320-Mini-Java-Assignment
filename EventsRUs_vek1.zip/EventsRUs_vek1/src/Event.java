import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Objects;
import java.util.Scanner;

/**
 * Represents all of the events in EventsRUs
 * @author vek1
 * @version 18/03
 */

public class Event implements Comparable<Event> {
    Calendar startDateTime;
    Calendar endDateTime;
    String name;
    Venue venue;
    boolean dataProjectorRequired;


    /**
     * Default constructor for the Event Class
     */

    public Event() {}
/**
 * Creates an Event object
 * @param theName the event Name
 * @param theStart When it starts
 * @param theEnd When it Ends
 */

    public Event(String theName, Calendar theStart, Calendar theEnd) {
    this.name = theName;
    this.startDateTime = theStart;
    this.endDateTime = theEnd;
}

    /**Returns the name of the Event
     * @return name
     */

    public String getName() {

    return name;
    }

    /** Sets the new name for the Event
     * @param name
     */

    public void setName(String name) {

    this.name = name;
    }

    /**Returns the required venue
     * @return venue
     */

    public Venue getVenue() {

        return venue;
    }

    /**
     * Sets the venue. This will only be allowed
     * if the meets the data projector requirement.
     * Otherwise displays an error message. This should really throw an exception
     * @param venue The venue for the talk
     */

    public void setVenue(Venue venue) {
        // Only allow this if the venue spec matches the
        // the talk requirement
        if (dataProjectorRequired && !venue.hasDataProjector()) {
            System.err.println("Talk " + name + " requires a data projector. " +
                    "Venue " + venue.getName() + " does not have one");
        } else {
            this.venue = venue;
        }
    }

    /**Returns whether or not the Projector is required
     * @return dataProjectorRequired
     */

    public boolean isDataProjectorRequired() {

        return dataProjectorRequired;
    }

    /**
     * Sets the data projector requirement. This will only be allowed
     * if there is an associated venue that meets the requirement.
     * Otherwise displays an error message. This should really throw an exception
     * @param dataProjectorRequired Whether required or not
     */

    public void setDataProjectorRequired(boolean dataProjectorRequired) {
        if (venue != null && (dataProjectorRequired && !venue.hasDataProjector())){
            System.err.println("Talk " + name + " currently has a venue " +
                    venue.getName() + " that does not have a data projector. Change the venue first");
        } else {
            this.dataProjectorRequired = dataProjectorRequired;
        }
    }


    /**Returns the start time of the event
     * @return startDateTime
     */

    public Calendar getStartDateTime() {

        return startDateTime;
    }

    /** Sets the end time for the Event and checks whether it's actually is accurate
     * @param startDateTime
     */

    public void setStartDateTime(Calendar startDateTime) {
        if(startDateTime.before(endDateTime)) {
            this.startDateTime = startDateTime;
        }
    }

    /**Returns the end time of the event
     * @return endDateTime
     */

    public Calendar getEndDateTime() {

        return endDateTime;
    }

    /** Sets the end time for the Event
     * @param endDateTime
     */

    public void setEndDateTime(Calendar endDateTime) {

        this.endDateTime = endDateTime;
    }

    /**
     * Returns information about the Event
     * @return information for printing
     */

    @Override
    public String toString() {

        int year = startDateTime.get(Calendar.YEAR);
        int month = startDateTime.get(Calendar.MONTH);
        int day = startDateTime.get(Calendar.DAY_OF_MONTH);
        int hour = startDateTime.get(Calendar.HOUR_OF_DAY);
        int minute = startDateTime.get(Calendar.MINUTE);

        StringBuilder results = new StringBuilder();

        results.append("Event starts at ");
        results.append(dateTimeToString(startDateTime));
        results.append(", and ends at ");
        results.append(dateTimeToString(endDateTime));
        results.append(". The name of the event is ");
        results.append(name);
        results.append(" and it will take place at the ");
        results.append(venue);
        results.append(" Data Projector required: ");
        results.append(dataProjectorRequired);

        return results.toString();
    }

    private String dateTimeToString(Calendar dateTime){

        int year = dateTime.get(Calendar.YEAR);
        int month = dateTime.get(Calendar.MONTH);
        int day = dateTime.get(Calendar.DAY_OF_MONTH);
        int hour = dateTime.get(Calendar.HOUR_OF_DAY);
        int minutes = dateTime.get(Calendar.MINUTE);

        return "" + year + ":" + month + ":" + day + ":" + hour + ":" + minutes;
    }

    /**
     * Reads in Event specific information from the file
     * @param infile An open file
     * @throws IllegalArgumentException if infile is null
     */

    public void load(Scanner infile) {
        if (infile == null) {
            throw new IllegalArgumentException("infile must not be null");
        }
        name = infile.next();
        startDateTime = readDateTime(infile);
        endDateTime = readDateTime(infile);

        dataProjectorRequired = infile.nextBoolean();
    }

    private Calendar readDateTime(Scanner scan) {
        Calendar result = Calendar.getInstance();

        int year = scan.nextInt();
        int month = scan.nextInt();
        int day = scan.nextInt();
        int hour = scan.nextInt();
        int minutes = scan.nextInt();

        result.clear();
        result.set(year, month, day, hour, minutes);

        return result;
    }

    /**
     * Writes out information about the Event to the file
     * @param outfile An open file
     * @throws IllegalArgumentException if outfile is null
     */

    public void save(PrintWriter outfile) {
        if (outfile == null)
            throw new IllegalArgumentException("outfile must not be null");
        outfile.println(name);
        writeDateTime(outfile, startDateTime);
        writeDateTime(outfile, endDateTime);

        outfile.println(dataProjectorRequired);

    }

    private void writeDateTime(PrintWriter outfile, Calendar dateTime) {
        outfile.println(dateTime.get(Calendar.YEAR));
        outfile.println(dateTime.get(Calendar.MONTH));
        outfile.println(dateTime.get(Calendar.DAY_OF_MONTH));
        outfile.println(dateTime.get(Calendar.HOUR_OF_DAY));
        outfile.println(dateTime.get(Calendar.MINUTE));
    }


    /**
     * Note that this only compares equality based on a
     * the name.
     * @param o the other talk to compare against.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;  // Are they the same object?
        if (o == null || getClass() != o.getClass()) return false; // Are they the same class?
        Event event = (Event) o;  // Do the cast to Talk
        // Now just check the names
        return Objects.equals(name, event.name); // Another way of checking equality. Also checks for nulls
    }

    @Override
    public int compareTo(Event e) {
        return this.startDateTime.compareTo(e.startDateTime);

    }
}