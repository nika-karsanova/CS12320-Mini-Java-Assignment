import java.util.Objects;


/**
 * Represents all of the Speaker of Conference
 * @author vek1
 * @version 22/03
 */

public class Speaker {
    private String name;
    private String phone;

    public Speaker(String name){
        this.name = name;
    }

    public Speaker(String name, String phone){
        this(name);
        this.phone = phone;

    }

    /**Returns the name of the speaker
     * @return name
     */
    public String getName() {
        return name;
    }

    /** Sets the name for the Speaker
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**Returns the phone number of the speaker
     * @return phone number
     */
    public String getPhone() {
        return phone;
    }

    /** Sets the phone name for the Speaker
     * @param phone
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Speaker speaker = (Speaker) o;
        return Objects.equals(name, speaker.name) &&
                Objects.equals(phone, speaker.phone);
    }

    /**
     * Returns information about the Speaker
     * @return info for printing
     */
    @Override
    public String toString() {
        StringBuilder results = new StringBuilder(); // CHANGED TO USE STRING BUILED

        results.append(name);
        results.append(" There phone number is: ");
        results.append(phone);

        return results.toString();

    }
}
