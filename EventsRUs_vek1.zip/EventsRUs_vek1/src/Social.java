import java.io.PrintWriter;
import java.util.Calendar;
import java.util.Scanner;

/**
 * Represent Social which is one of the possible Events
 * @author vek1
 * @version 18/03
 */

public class Social extends Event {
    private boolean foodOrDrinksRequired;
    private boolean invitationOnly;

    public Social() {
    }

    /**
     * Constructor for the Social
     *
     * @param theName       the Name of the Social Event
     * @param theStart      the Start time of the Social
     * @param theEnd        the End time of the Social
     * @param foodAndDrinks whether or not food and drinks are required
     * @param theInvitation whether or not invitation is required
     */

    public Social(String theName, Calendar theStart, Calendar theEnd, boolean foodAndDrinks, boolean theInvitation) {
        super(theName, theStart, theEnd);
        foodOrDrinksRequired = foodAndDrinks;
        invitationOnly = theInvitation;

    }

    /**
     * Returns whether or not food and drinks are required
     *
     * @return foodOrDrinksRequired
     */

    public boolean foodOrDrinksRequired() {
        return foodOrDrinksRequired;
    }

    /**
     * Sets whether or not the Social requires food and drinks
     *
     * @param foodOrDrinksRequired
     */

    public void areFoodOrDrinksRequired(boolean foodOrDrinksRequired) {

        this.foodOrDrinksRequired = foodOrDrinksRequired;
    }

    /**
     * Returns whether or not the Social is invitation only
     *
     * @return isInvitationOnly
     */

    public boolean invitationOnly() {
        return invitationOnly;
    }

    /**
     * Sets whether or not the Social is Invitation only
     *
     * @param invitationOnly
     */

    public void isInvitationOnly(boolean invitationOnly) {
        invitationOnly = invitationOnly;
    }

    /**
     * Returns information about the Social
     *
     * @return information for printing
     */
    @Override
    public String toString() {

        StringBuilder results = new StringBuilder(); // CHANGED TO USE STRING BUILED

        results.append("Food and Drinks are required: ");
        results.append(foodOrDrinksRequired);
        results.append("Social is invitation only: ");
        results.append(invitationOnly);

        return super.toString() + results.toString();
    }

    /**
     * Reads in Social specific information from the file
     *
     * @param infile An open file
     * @throws IllegalArgumentException if infile is null
     */
    @Override
    public void load(Scanner infile) {
        super.load(infile);

        if (infile == null) {
            throw new IllegalArgumentException("infile must not be null");
        }

            foodOrDrinksRequired = infile.nextBoolean();
            invitationOnly = infile.nextBoolean();

    }


    /**
     * Writes out information about the Social to the file
     * @param outfile An open file
     * @throws IllegalArgumentException if outfile is null
     */
    @Override
    public void save(PrintWriter outfile) {

        outfile.println("2");
        super.save(outfile);

        if (outfile == null) {
            throw new IllegalArgumentException("outfile must not be null");
        }

        outfile.println(foodOrDrinksRequired);
        outfile.println(invitationOnly);

        }
    }


